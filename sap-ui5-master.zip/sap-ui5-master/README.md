sap-ui5
=======

These SAPUI5 Applications are based on public JSON APIs. You will find 4 applications based on,
1) Weather Underground JSON API
2) GeoNames wikipediaSearch JSON API
3) Rotten Tomatoes JSON API
4) Open Weather Map JSON API

For more information, please visit SCN blog at 
http://scn.sap.com/community/developer-center/front-end/blog/2013/08/01/creating-sapui5-applications-based-on-public-json-apis-or-web-services
